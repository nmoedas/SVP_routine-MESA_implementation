module MOD_SVP
   use star_lib
   use star_def
   use const_def

   implicit none
   private
   public :: initialize_SVP, id_ppxi, C_ref, isotops , g_rad_SVP
   integer, parameter                       :: pnchim = 40 , pzi=26

   ! igrad  (if =0 g_rad of unidentified elements will be set equal to zero)
   !        (if =1 g_rad of unidentified elements will be set equal to -local_gravity)
   ! tgrad  (if =0 g_rad of identified elements will be set equal to zero)     
   !        (if =1 g_rad of identified elements will be set equal to -local_gravity)
   !        (if =2 g_rad of identified elements will be set equal computed)  

   integer, save  :: igrad = 0 , tgrad = 2      ! forced here

   integer, parameter                      :: nion_ppxi=30
   real(dp), dimension(0:nion_ppxi,pnchim) :: phistar,psistar
   real(dp), dimension(0:nion_ppxi,pnchim) :: xistar,alphstar
   real(dp), dimension(0:nion_ppxi,pnchim) :: acstar,betstar

   integer, dimension(pnchim)                     :: id_ppxi
   integer, dimension(pnchim,pnchim)              :: isotops
  
   character(Len=2), dimension(pnchim)           :: el_svp
   character(len=255)                            :: nomch 
   real(dp), dimension(pnchim)                   :: C_ref


   integer, dimension(0:pzi,pnchim)     :: niv_flag,niv_nb,niv_z
   integer, dimension(0:pzi,pnchim)     :: rar_flag
   real(dp), dimension(0:pzi,pnchim)    :: el_pot
   
   logical :: DEV=.true.
   !logical :: DEV=.false.

   ! Energy levels of ions: table(niveau,deg_ionisation,numero_element_cesam) 

   integer, dimension(99,0:pzi,pnchim)  :: niv_g
   real(dp), dimension(99,0:pzi,pnchim) :: niv_e,niv_q

   contains
!===================================================================
   subroutine initialize_SVP(mtot,nchim,nom_elem,nucleo,Zi,version)

      implicit none

      character(64)           :: version
      real(dp), intent(in)    :: mtot
      integer, intent(in)     :: nchim
      real(dp), dimension(:), intent(in) :: nucleo
      character(len=8), dimension(:), intent(in) :: nom_elem
      integer, dimension(:), intent(in)         :: Zi
     
      
    
      print'(/,"Version of the SVP data: ",a,/)',TRIM(ADJUSTL(version))
      write(10,'(/,"Version of the SVP data: ",a,/)') TRIM(ADJUSTL(version))
     
     
      call getcwd(nomch)
      nomch=trim(nomch)//'/src/SVP/'
      call sb_initsvp(mtot,nchim,nom_elem,nucleo,Zi,version) 
   end subroutine initialize_SVP 
!=======================================================================
!=======================================================================         
   subroutine g_rad_SVP(nchim,nom_elem,nucleo,Zi,mtot,rtot,teff, &
                          mass,ray,t,nel,ychim,g_rad,dg_rad)

!   This subroutine computes radiative acceleration and derivatives  
!     relative to abundances. It must be called for each layer and
!   each time atomic diffusion is computed.

! Inputs, for the layer:
!     ray: radius      
!     t : temperature   
!     nel : number of electrons per volume,
!     ychim : chemical composition per mole
!     grav : gravity        
! Outputs        
!     g_rad(i) : radiative acceleration
!     dg_rad(i,j) : derivative 

!--------------------------------------------------------------

      implicit none
      
      real(dp), intent(in)               :: mtot,rtot,teff,mass,ray,t,nel
      real(dp), dimension(:), intent(in) :: ychim,nucleo
      integer, intent(in)                :: nchim
      integer, dimension(:), intent(in)         :: Zi
      
      character(8), dimension(:), intent(in)    :: nom_elem
      
      real(dp), dimension(:,:), intent(out) :: dg_rad
      real(dp), dimension(:), intent(out) :: g_rad
         
      !print*, '-----------------------------------------------------------------'
      !print*, 'mass ',mass
      !print*, 'ray ',ray
      !print*, 't ',t             
      !print*, 'nel ',nel
      !print*, 'ychim ',ychim(1:nchim) 
      !stop
      
      
      call sb_g_rad2(nchim,nom_elem,nucleo,Zi,mtot,rtot,teff, &
                          mass,ray,t,nel,ychim,g_rad,dg_rad)
      !print*, 'g_rad ',g_rad(1:nchim)
      
   end subroutine g_rad_SVP
!=======================================================================


   include "svp_codes.f"
end module MOD_SVP
